# Obs-32 independent review — scratch evidence bundle

Bounded, read-only diagnostic evidence behind the independent review of the
Phase-6A-1 observation-32 forensics and the proposed ADR-0017 piecewise-smooth
amendment (review report: `REVIEW_REPORT.md`). Generated 2026-10-01 on the local
Mac. **Not committed anywhere; nothing in any repository or worktree was modified.**
No full trajectory, campaign, REFINED/ULTRA campaign tier, or production change was run.

## Provenance

| Item | Value |
|---|---|
| Reviewed worktree / SHA | `CompactStar-phase6a1-obs32-reconstruction-forensics` @ `669898c6741883ecacdc7e2fa2599cfa3df92918` (clean before and after) |
| Campaign entry / canonical master | `7d2777561a17b56b466fb024ef13104da6c0e86a` / `9a5c1eca40758e4c39f9f80db7324e12ad23e505` (unchanged) |
| Linked library | `build/obs32/libCompactStar.a` SHA-256 `70239a1d463c94471c71f715a00e1755aeb5e3d0359f817d75ba4bcb3049d017` (= forensics `packages.json`) |
| Dependencies | libZaki.a `f30e68b2…`, libCONFIND.a `1f36fc6e…`, libgsl.dylib `9667d3f9…` (GSL 2.7.1), AppleClang 21.0.0 arm64, `-g -std=c++17` |
| Inputs | the six inputs of the forensics run (profile tree, certificate, thermal tree, entry hashes, frozen certificate, coefficients); all six re-authenticated against `evidence/obs32-forensics/authentication.json` (trees via `tests/bnv/adr0017_production_verify.py::tree_sha256`) |
| Production source | unchanged between entry `7d27775` and `669898c` |

## Build and run (exact)

```sh
WT=/Users/keeper/Documents/CompactStar/worktrees/CompactStar-phase6a1-obs32-reconstruction-forensics
Q=/Users/keeper/Documents/CompactStar/external/qualification/compactstar-migration/e263a6e-b0cbd510/Debug
/usr/bin/clang++ -g -std=c++17 -I$WT/build/obs32/generated/include -I$WT -I$WT/tests/bnv \
  -isystem /opt/local/include -isystem $Q/Zaki/include -isystem $Q/CONFIND/include \
  harness/review_obs32_vN.cpp -o review_obs32_vN $WT/build/obs32/libCompactStar.a \
  $Q/CONFIND/lib/libCONFIND.a $Q/Zaki/lib/libZaki.a -lz /opt/local/lib/libgsl.dylib /opt/local/lib/libgslcblas.dylib
```

Run from a scratch working directory containing byte-identical copies of the four
provenance files the fixture copies relative to CWD
(`CompactStar/EOS/src/TrackRFreeGasThermodynamics.cpp`, `CompactStar/EOS/src/LocalThermodynamics.cpp`,
`CompactStar/EOS/TrackRFreeGasThermodynamics.hpp`, `CompactStar/EOS/LocalThermodynamics.hpp`):

```sh
B=/Users/keeper/Documents/CompactStar/worktrees/CompactStar-phase6a1-controlled-bnv-implementation
[REVIEW_ONLY_WINDOWS=1] ./review_obs32_vN \
  $B/build/phase6a1-controlled-bnv-debug/phase6a1-fresh-qualification/chemical-characterization/run-dhp6aivf/t8192-r80000 \
  $B/build/phase6a1-controlled-bnv-debug/phase6a1-fresh-qualification/certificate-t8192-r80000.txt \
  $B/build/phase6a1-controlled-bnv-debug/phase6a1-frozen-certificate-final/chemical-profiles/target-0/thermal \
  <fresh-work-dir> $B/docs/validation/phase6a1_controlled_bnv_entry_hashes.json \
  $B/build/phase6a1-controlled-bnv-debug/phase6a1-frozen-certificate-final/certificate.tsv \
  $B/build/phase6a1-controlled-bnv-debug/phase6a1-frozen-certificate-final/coefficients.tsv \
  $WT/docs/validation/evidence/obs32-forensics/cases.tsv <bundle>/inputs <fresh-output-dir>
```

`inputs/` is produced by `harness/prep_steps.py` from the committed campaign archive
(`docs/validation/evidence/bnv-resume/clean-campaign/*/main.*.tsv.gz`).

## Layout and validity

| Path | Produced by | Status |
|---|---|---|
| `harness/review_obs32_v1.cpp` | — | harness that produced run2 |
| `harness/review_obs32_v2.cpp` | — | v1 + GSL evolve-cache reset after an undone trial step + windows-only switch; produced run3 |
| `harness/review_obs32_v3.cpp` | — | v2 + frozen-cell segment option + D4F + output-stream checks; produced run4 |
| `harness/review_metadata.py` → `metadata/metadata.json` | archived metadata only | VALID (no ODE). Note: its per-crossing "predicted" signs for the *control* use the source sign convention; magnitudes are right. Sign-correct predictions are in `runs/run2-primary/analysis.json` |
| `harness/analyze_run.py` → `runs/run2-primary/analysis.json` | run2 outputs | VALID (Peano-kernel model vs every replayed crossing, sign convention `[y'']=-dir*kappa*xdot^2`) |
| `harness/review_followups.py` → `harness/review_followups.out` | committed forensics evidence + this bundle | VALID (δT, sensitivities, monotonicity, linearized propagation, residual gate-failure localization) |
| `harness/gsl_order.c` / `.out` | standalone GSL | VALID: GSL rkf45 propagates 5th order; GSL single-step ramp errors equal the K5/Kerr kernels |
| `harness/gsl_reuse.c` / `.out` | standalone GSL | VALID: evolve reuses the previous dydt_out (undo without `gsl_odeiv2_evolve_reset` corrupts the next step); a clipped final step leaves `h` unchanged |
| `runs/run1-failed-cwd/run1.log` | v1 | FAILED before any computation (fixture `copy_file` relative to CWD); no outputs |
| `runs/run2-primary/` | v1 | VALID: `D0-reproduction`, `D-obs32`, `D4-fixed-step`, `D5-event-perturbation`, `D6-smooth-controls`, `K-replays`, `K-attempts`, `knots`, `P-persistence`, and every **unsplit** column/row of `M-*`. **INVALID: every `*-split` column/row of `M-*`** (harness bug: stale GSL evolve derivative after undoing a straddling trial) |
| `runs/run3-corrected-split/` | v2 | VALID split and unsplit windows, **except `M-control-observations.tsv`, which is corrupt from data row 599 on** (writes failed while the disk was full: a block of earlier rows reappears and the last row is cut). Do not use that file; `runs/run4-frozen-cell/M-control-observations.tsv` supersedes it. `M-control-gate.tsv` / `M-control-true-error.tsv` were computed in memory over all 1277 observations and are complete |
| `runs/run4-frozen-cell/` | v3 | VALID and complete: `D4F-frozen`, all three window forms (`unsplit`, `split`, `frozen`) for source and control |

Cross-run checks: unsplit step counts, endpoints and every unsplit observation column are bitwise
identical across run2/run3/run4 (run3's control file compared only up to its corruption point);
`P-persistence.tsv` is identical across all three; the tight references of run2 (actual-cell split)
and run4 (frozen-cell split) agree bitwise at every source and control observation time.

## File conventions

- State: `x = ln(Tinf / 1e8 K)`, `eta_e`, `eta_mu` in MeV; time in seconds; tolerances
  `D = atol + rtol*|y|` per GSL `control_scaled_new(1, rtol, 1, 0, atol)`.
- Tolerance tiers: BASELINE `1e-7/(1e-12,1e-18,1e-18)`, REFINED `1e-9/(1e-14,1e-20,1e-20)`,
  ULTRA `1e-11/(1e-16,1e-22,1e-22)`; rk8pd levels O1–O4 `1e-12…1e-15` with matching atol.
- `K-replays.tsv`: bitwise replay of archived main steps from saved `(t, y, h_proposal)`
  (`bitwise=1` for all 60), local error `e = y_main − y_ref` vs rk8pd O4 split reference.
- `K-attempts.tsv`: every GSL trial (incl. rejections) of each replayed step with its error estimate.
- `M-<run>-runs/steps/events/observations/gate/true-error.tsv`: bounded windows started from a saved
  archived state (source: end of step 20; control: end of step 49), three tiers × forms;
  observations by ideal passive reconstruction (rk8pd O3, split) from each run's own accepted
  left state; reference = rk8pd O4 split at every knot. `gate` applies the BA12R state logic
  (`c1: d_RU/D_R ≤ 1`, `c2: d_RU/d_BR ≤ 0.10 if d_BR > 10F`, `c3: d_RU ≤ 10F otherwise`).
- `P-persistence.tsv`: tight split propagation of the knot-95 local error from `t_R`.

## Not included

Compiled executables and dSYM bundles (machine-specific; rebuild with the command above),
the three tiny fixture work directories (regenerated on each run), and the scratch CWD copies
of the four provenance sources (byte-identical to the worktree at `669898c`).

`SHA256SUMS` lists every file in this bundle.
