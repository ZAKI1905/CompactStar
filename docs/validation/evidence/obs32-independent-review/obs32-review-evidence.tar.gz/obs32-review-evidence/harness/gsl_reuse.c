#include <stdio.h>
#include <gsl/gsl_odeiv2.h>
#include <gsl/gsl_errno.h>
static int calls=0;
static int f(double t,const double y[],double d[],void*p){(void)t;(void)p;++calls;d[0]=y[0]*y[0]*0.1+y[0];return GSL_SUCCESS;}
int main(void){
  gsl_odeiv2_system s={f,0,1,0};
  gsl_odeiv2_step* st=gsl_odeiv2_step_alloc(gsl_odeiv2_step_rkf45,1);
  gsl_odeiv2_control* c=gsl_odeiv2_control_standard_new(1e-12,1e-12,1,0);
  gsl_odeiv2_evolve* e=gsl_odeiv2_evolve_alloc(1);
  double t=0,h=0.1,y=1; calls=0;
  gsl_odeiv2_evolve_apply(e,c,st,&s,&t,10,&h,&y); printf("step1 calls=%d t=%g y=%.17g\n",calls,t,y);
  double t1=t,y1=y,h1=h;
  calls=0; gsl_odeiv2_evolve_apply(e,c,st,&s,&t,10,&h,&y); printf("step2 calls=%d (6 => dydt_in reused, 7 => recomputed)\n",calls);
  /* undo step 2, re-apply with same objects */
  double ta=t1,ya=y1,ha=h1; calls=0; gsl_odeiv2_evolve_apply(e,c,st,&s,&ta,10,&ha,&ya); printf("undo+reapply same evolve: y=%.17g calls=%d\n",ya,calls);
  /* reference: fresh evolve from (t1,y1,h1) */
  gsl_odeiv2_evolve* e2=gsl_odeiv2_evolve_alloc(1); double tb=t1,yb=y1,hb=h1; gsl_odeiv2_evolve_apply(e2,c,st,&s,&tb,10,&hb,&yb); printf("fresh evolve:             y=%.17g\n",yb);
  gsl_odeiv2_evolve_reset(e); double tc=t1,yc=y1,hc=h1; gsl_odeiv2_evolve_apply(e,c,st,&s,&tc,10,&hc,&yc); printf("after evolve_reset:       y=%.17g\n",yc);
  /* final-step h semantics: apply with t1 just ahead, check returned h */
  double td=t1,yd=y1,hd=h1; gsl_odeiv2_evolve_reset(e); gsl_odeiv2_evolve_apply(e,c,st,&s,&td,t1+0.3*h1,&hd,&yd); printf("clipped final step: h_in=%.17g h_out=%.17g t=%.17g\n",h1,hd,td);
  return 0;}
