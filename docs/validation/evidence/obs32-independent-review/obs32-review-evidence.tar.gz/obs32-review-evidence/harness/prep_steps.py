import gzip, csv, sys
WT="/Users/keeper/Documents/CompactStar/worktrees/CompactStar-phase6a1-obs32-reconstruction-forensics"
C=WT+"/docs/validation/evidence/bnv-resume/clean-campaign"
def rows(p):
    with gzip.open(p,"rt") as f: return list(csv.DictReader(f,delimiter="\t"))
out=open("exp/steps.tsv","w")
out.write("run\tseq\tt0\tx0\te0\tm0\th_prop\tt1\tx1\te1\tm1\tkind\n")
sel={"source":{"cross":[17,21,25,28,32,38,47,67],"rej":[24,31,45,48,116,117],"smooth":[16,19,20,22,23,26,27]},
     "control":{"cross":None,"rej":[19,20,23,26,35,39],"smooth":[16,18,22,25]}}
for run in ("source","control"):
    acc=rows(f"{C}/{run}-baseline/main.accepted_states.tsv.gz")
    it=rows(f"{C}/{run}-baseline/main.internal_steps.tsv.gz")
    cross=[int(r["sequence"]) for r in it if int(r["cstar_knots_crossed"])>0]
    s=sel[run]; cr=s["cross"] or cross
    assert set(cr)<=set(cross), (run, set(cr)-set(cross))
    kinds={**{q:"smooth" for q in s["smooth"]},**{q:"rejection" for q in s["rej"]},**{q:"crossing" for q in cr}}
    for q in sorted(kinds):
        cur=acc[q-1]; assert int(cur["sequence"])==q
        if q==1: prev={"t_after_s":"0","x_state":"0","eta_e_MeV":"0","eta_mu_MeV":"0","suggested_next_h_s":"1"}
        else: prev=acc[q-2]
        assert prev.get("t_after_s")==cur["t_before_s"] or q==1
        out.write("\t".join([run,str(q),cur["t_before_s"],prev["x_state"],prev["eta_e_MeV"],prev["eta_mu_MeV"],prev["suggested_next_h_s"],
                             cur["t_after_s"],cur["x_state"],cur["eta_e_MeV"],cur["eta_mu_MeV"],kinds[q]])+"\n")
    # full archived accepted list for window authentication
    with open(f"exp/{run}-accepted.tsv","w") as f:
        f.write("seq\tt0\tt1\th_next\tx\te\tm\trej\n")
        for r in acc: f.write("\t".join([r["sequence"],r["t_before_s"],r["t_after_s"],r["suggested_next_h_s"],r["x_state"],r["eta_e_MeV"],r["eta_mu_MeV"],r["cumulative_rejected"]])+"\n")
out.close()
print(open("exp/steps.tsv").read().count("\n")-1,"step rows")
