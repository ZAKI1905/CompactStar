#!/usr/bin/env python3
"""Post-process the scratch review diagnostic outputs (no ODEs)."""
import csv, math, sys, json
from fractions import Fraction as Fr
O = sys.argv[1]
def rows(p):
    with open(p) as f:
        return list(csv.DictReader(f, delimiter="\t"))
kB = 8.61733326214518e-5 * 1e-6
c = [0, 1/4, 3/8, 12/13, 1, 1/2]
b5 = [16/135, 0, 6656/12825, 28561/56430, -9/50, 2/55]
ec = [1/360, 0, -128/4275, -2197/75240, 1/50, 2/55]
def K5(th): return sum(bi*max(ci-th, 0) for bi, ci in zip(b5, c)) - (1-th)**2/2
def Ke(th): return sum(e*max(ci-th, 0) for e, ci in zip(ec, c))
kn = rows(O + "/knots.tsv"); T = [float(r["T_MeV"]) for r in kn]; C = [float(r["C"]) for r in kn]
def kappa(k):
    s0 = (C[k]-C[k-1])/math.log(T[k]/T[k-1]); s1 = (C[k+1]-C[k])/math.log(T[k+1]/T[k]); return (s1-s0)/C[k]
res = {}
# ---------------- K replays
kr = rows(O + "/K-replays.tsv"); ka = rows(O + "/K-attempts.tsv")
out = []
for r in kr:
    e = float(r["e_x"]); D = float(r["D_x"]); h = float(r["h"])
    d = dict(run=r["run"], seq=int(r["seq"]), kind=r["kind"], bitwise=r["bitwise"], h=h, e_x=e, e_over_D=e/D,
             e_eta_e=float(r["e_eta_e"]), e_eta_mu=float(r["e_eta_mu"]))
    if r["n_events"] != "0":
        k = int(r["knot"]); tk = float(r["t_event"]); t0 = float(r["t0"]); f = float(r["xdot_event"]); dirn = 1 if r["run"] == "source" else -1
        th = (tk - t0)/h; jump = -dirn*kappa(k)*f*f  # [y''] = -dir*kappa*f^2
        d.update(knot=k, theta=th, pred_e=jump*h*h*K5(th), pred_est=jump*h*h*Ke(th), A=abs(K5(th)/Ke(th)) if Ke(th) else math.inf)
        d["pred_over_obs"] = d["pred_e"]/e if e else math.nan
        att = [a for a in ka if a["run"] == r["run"] and a["seq"] == r["seq"]]
        d["attempts"] = []
        for a in att:
            ha = float(a["h"]); tha = (tk - t0)/ha
            pe = jump*ha*ha*Ke(tha) if tha < 1 else 0.0
            d["attempts"].append(dict(h=ha, theta=tha, err_x=float(a["err_x"]), model_err=pe, ratio_to_D=float(a["ratio"])))
    out.append(d)
res["K"] = out
# ---------------- D
D = rows(O + "/D-obs32.tsv"); res["D"] = D
res["D4"] = rows(O + "/D4-fixed-step.tsv"); res["D5"] = rows(O + "/D5-event-perturbation.tsv")
res["D0"] = rows(O + "/D0-reproduction.tsv"); res["D6"] = rows(O + "/D6-smooth-controls.tsv")
for tag in ("source", "control"):
    try:
        res["M-"+tag] = dict(runs=rows(O+f"/M-{tag}-runs.tsv"), gate=rows(O+f"/M-{tag}-gate.tsv"),
                             err=rows(O+f"/M-{tag}-true-error.tsv"), events=rows(O+f"/M-{tag}-events.tsv"))
    except FileNotFoundError:
        pass
try: res["P"] = rows(O + "/P-persistence.tsv")
except FileNotFoundError: pass
json.dump(res, open(O + "/analysis.json", "w"), indent=1, default=str)
# print compact summaries
for d in out:
    s = f"{d['run']:7s} {d['seq']:3d} {d['kind']:9s} bit={d['bitwise']} h={d['h']:.4e} e_x={d['e_x']:+.4e} e/D={d['e_over_D']:+8.3f}"
    if "knot" in d:
        s += f" k={d['knot']} th={d['theta']:.4f} pred={d['pred_e']:+.4e} pred/obs={d['pred_over_obs']:.3f} A={d['A']:.1f} att={len(d['attempts'])}"
    print(s)
