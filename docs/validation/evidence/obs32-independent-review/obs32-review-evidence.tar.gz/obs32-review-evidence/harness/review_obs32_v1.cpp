// Scratch-only bounded diagnostic for the independent Phase-6A-1 obs-32 review.
// NOT part of the repository. Reads authenticated inputs; writes only to scratch.
// No production code is modified; no full trajectory or campaign is run.
#define OBS32_SUPPORT_ONLY
#include "obs32_forensics.cpp"
#include <gsl/gsl_errno.h>
#include <gsl/gsl_odeiv2.h>
#include <gsl/gsl_version.h>
#include <map>

namespace Rv {
using State=BNV::CheckpointState;
using Ctx=std::shared_ptr<const BNV::FrozenControlledBnvRunContext>;
using Probe::TM;
const double T_FINAL=15778800000000.;
const double OBS_DT=T_FINAL/8192.;

struct Tol{const char* name;double rtol;State atol;};
const Tol BASE{"BASELINE",1e-7,{{1e-12,1e-18,1e-18}}};
const Tol REFI{"REFINED",1e-9,{{1e-14,1e-20,1e-20}}};
const Tol ULTR{"ULTRA",1e-11,{{1e-16,1e-22,1e-22}}};
const Tol L1{"O1",1e-12,{{1e-17,1e-23,1e-23}}};
const Tol L2{"O2",1e-13,{{1e-18,1e-24,1e-24}}};
const Tol L3{"O3",1e-14,{{1e-19,1e-25,1e-25}}};
const Tol L4{"O4",1e-15,{{1e-20,1e-26,1e-26}}};

struct Attempt{double t,h;State before,after,err;int rc;};
thread_local std::vector<Attempt>* g_log=nullptr;
int LogApply(void* o,size_t n,double t,double h,double* y,double* e,const double* di,double* doo,const gsl_odeiv2_system* s)
{
    Attempt a{t,h,{{y[0],y[1],y[2]}},{},{},0};
    const int rc=gsl_odeiv2_step_rkf45->apply(o,n,t,h,y,e,di,doo,s);
    a.after={{y[0],y[1],y[2]}};a.err={{e[0],e[1],e[2]}};a.rc=rc;
    if(g_log)g_log->push_back(a);
    return rc;
}
gsl_odeiv2_step_type MakeLogged(){auto t=*gsl_odeiv2_step_rkf45;t.apply=LogApply;return t;}
const gsl_odeiv2_step_type LOGGED_RKF45=MakeLogged();

struct Rhs
{
    Ctx phys;std::unique_ptr<ActualCheckpointContext> ctx;std::size_t calls=0;std::exception_ptr fail;
    Rhs(Ctx p,std::size_t id):phys(p),ctx(std::make_unique<ActualCheckpointContext>(p,id)){}
    void Eval(double t,const State& y,State& dy){ctx->Derivative(t,y,dy);++calls;}
    static int F(double t,const double* y,double* d,void* p) noexcept
    {
        auto& r=*static_cast<Rhs*>(p);
        try{State in{{y[0],y[1],y[2]}},out{};r.Eval(t,in,out);for(int i=0;i<3;++i)d[i]=out[i];return GSL_SUCCESS;}
        catch(...){r.fail=std::current_exception();return GSL_EBADFUNC;}
    }
};

struct Gsl
{
    gsl_odeiv2_step* s=nullptr;gsl_odeiv2_control* c=nullptr;gsl_odeiv2_evolve* e=nullptr;
    Gsl(const gsl_odeiv2_step_type* T,const Tol& tol)
    {
        s=gsl_odeiv2_step_alloc(T,3);c=gsl_odeiv2_control_scaled_new(1.0,tol.rtol,1.0,0.0,tol.atol.data(),3);
        e=gsl_odeiv2_evolve_alloc(3);require(s&&c&&e,"gsl alloc");
    }
    ~Gsl(){gsl_odeiv2_evolve_free(e);gsl_odeiv2_control_free(c);gsl_odeiv2_step_free(s);}
    Gsl(const Gsl&)=delete;Gsl& operator=(const Gsl&)=delete;
};

struct Sol{State y{};double t=0;std::size_t acc=0,rej=0,rhs=0;};
Sol Adaptive(Rhs& f,const gsl_odeiv2_step_type* T,const Tol& tol,double t0,State y,double t1,double h0)
{
    Gsl g(T,tol);gsl_odeiv2_system sys{Rhs::F,nullptr,3,&f};double t=t0,h=h0;const std::size_t c0=f.calls;std::size_t n=0;
    while(t<t1)
    {
        require(++n<400000,"adaptive budget");
        const int rc=gsl_odeiv2_evolve_apply(g.e,g.c,g.s,&sys,&t,t1,&h,y.data());
        if(f.fail)std::rethrow_exception(f.fail);require(rc==GSL_SUCCESS,"adaptive gsl failure");
    }
    return {y,t,static_cast<std::size_t>(g.e->count),static_cast<std::size_t>(g.e->failed_steps),f.calls-c0};
}
State Fixed(Rhs& f,const gsl_odeiv2_step_type* T,double t0,State y,double t1,long N)
{
    auto* s=gsl_odeiv2_step_alloc(T,3);gsl_odeiv2_system sys{Rhs::F,nullptr,3,&f};const double H=(t1-t0)/double(N);double err[3];
    for(long i=0;i<N;++i)
    {
        const double t=t0+double(i)*H;const double h=i==N-1?t1-t:H;
        const int rc=gsl_odeiv2_step_apply(s,t,h,y.data(),err,nullptr,nullptr,&sys);
        if(f.fail)std::rethrow_exception(f.fail);require(rc==GSL_SUCCESS,"fixed step failure");
    }
    gsl_odeiv2_step_free(s);return y;
}

struct Knots{std::vector<double> T,C;};
int NextKnot(const Knots& K,double Tm,int dir)
{
    if(dir>0){for(std::size_t i=1;i+1<K.T.size();++i)if(K.T[i]>Tm)return int(i);return -1;}
    for(std::size_t i=K.T.size()-2;i>=1;--i)if(K.T[i]<Tm)return int(i);return -1;
}
bool Beyond(const Knots& K,int k,double Tm,int dir){return k>=0&&(dir>0?Tm>K.T[k]:Tm<K.T[k]);}

struct Ev{int knot=-1;double t=0;State y{};int iters=0;double g_MeV=0;double last_dt=0;std::size_t ivps=0;};
Ev Locate(Rhs& f,const gsl_odeiv2_step_type* T,const Tol& tol,double t0,const State& y0,const Knots& K,int k,double hi,int dir)
{
    const double Tk=K.T[k];
    auto G=[&](const State& y){return dir*(TM(y[0])-Tk);};
    require(G(y0)<0,"event: start not before knot");
    double lo=t0,t=t0,g=G(y0),prev=INFINITY;State y=y0;Ev r;r.knot=k;
    for(int it=0;it<40;++it)
    {
        State dy;f.Eval(t,y,dy);const double dg=dir*TM(y[0])*dy[0];require(dg>0,"event: non-monotone approach");
        double tn=t-g/dg;if(!(tn>lo&&tn<hi))tn=0.5*(lo+hi);if(tn==t)break;
        auto s=Adaptive(f,T,tol,t0,y0,tn,tn-t0);++r.ivps;const double gn=G(s.y);const double dt=std::abs(tn-t);
        if(gn<0)lo=tn;else hi=tn;t=tn;y=s.y;g=gn;r.iters=it+1;r.last_dt=dt;
        if(gn==0||dt<1e-3)break;if(it>=3&&dt>0.5*prev)break;prev=dt;
    }
    r.t=t;r.y=y;r.g_MeV=dir*g;return r;
}
State SplitAdvance(Rhs& f,const Knots& K,const gsl_odeiv2_step_type* T,const Tol& tol,double& t,State y,double t1,int dir,
                   std::vector<Ev>* evs=nullptr,std::size_t* legs=nullptr)
{
    int k=NextKnot(K,TM(y[0]),dir);
    while(t<t1)
    {
        auto s=Adaptive(f,T,tol,t,y,t1,t1-t);
        if(!Beyond(K,k,TM(s.y[0]),dir)){t=t1;y=s.y;if(legs)++*legs;break;}
        auto ev=Locate(f,T,tol,t,y,K,k,t1,dir);
        t=ev.t;y=ev.y;if(evs)evs->push_back(ev);if(legs)++*legs;k+=dir;
    }
    return y;
}

struct Step{double t0,t1;State y0,y1;double hnext;std::size_t rej_cum;int boundary_knot=-1;};
struct Main{std::vector<Step> steps;std::vector<Ev> events;std::vector<Attempt> attempts;std::size_t rhs=0,wasted=0,rej=0;};
Main RunMain(Rhs& f,const Knots& K,const Tol& tol,double t0,State y,double h,double t_stop,int dir,bool split,bool log)
{
    Gsl g(log?&LOGGED_RKF45:gsl_odeiv2_step_rkf45,tol);gsl_odeiv2_system sys{Rhs::F,nullptr,3,&f};
    Main m;double t=t0;const std::size_t c0=f.calls;int k=NextKnot(K,TM(y[0]),dir);
    while(t<t_stop)
    {
        const double ts=t,hs=h;const State ys=y;
        if(log)g_log=&m.attempts;
        int rc=gsl_odeiv2_evolve_apply(g.e,g.c,g.s,&sys,&t,T_FINAL,&h,y.data());
        g_log=nullptr;if(f.fail)std::rethrow_exception(f.fail);require(rc==GSL_SUCCESS,"main gsl failure");
        if(!split||!Beyond(K,k,TM(y[0]),dir))
        {
            while(Beyond(K,k,TM(y[0]),dir))k+=dir;
            m.steps.push_back({ts,t,ys,y,h,static_cast<std::size_t>(g.e->failed_steps)});continue;
        }
        const double t_trial=t;t=ts;y=ys;h=hs;++m.wasted;
        auto ev=Locate(f,gsl_odeiv2_step_rkf45,tol,ts,ys,K,k,t_trial,dir);m.events.push_back(ev);
        while(t<ev.t)
        {
            const double a=t;const State ya=y;
            rc=gsl_odeiv2_evolve_apply(g.e,g.c,g.s,&sys,&t,ev.t,&h,y.data());
            if(f.fail)std::rethrow_exception(f.fail);require(rc==GSL_SUCCESS,"main landing failure");
            m.steps.push_back({a,t,ya,y,h,static_cast<std::size_t>(g.e->failed_steps),t==ev.t?k:-1});
        }
        k+=dir;
    }
    m.rhs=f.calls-c0;m.rej=g.e->failed_steps;return m;
}
State Observe(Rhs& f,const Knots& K,const Main& m,double tobs,int dir,const Tol& tol=L3)
{
    auto it=std::lower_bound(m.steps.begin(),m.steps.end(),tobs,[](const Step& s,double v){return s.t1<v;});
    require(it!=m.steps.end()&&it->t0<tobs&&tobs<=it->t1,"observation outside run");
    if(tobs==it->t1)return it->y1;double t=it->t0;return SplitAdvance(f,K,gsl_odeiv2_step_rk8pd,tol,t,it->y0,tobs,dir);
}
double Ulp(double m){const double n=std::nextafter(m,INFINITY);return n-m;}
std::string S(const State& y){std::ostringstream o;o<<std::setprecision(17)<<y[0]<<'\t'<<y[1]<<'\t'<<y[2];return o.str();}

struct Pair{Ctx source,control;};
Pair BuildBoth(const Inputs& inputs)
{
    const auto& card=Campaign::RunCards().back();
    require(card.identity=="CPL-P2-LINEAR-QSS-v1"&&card.partition=="P2"&&card.fractional_drive_per_year==-1.0e-12
      &&card.duration_year==5.0e5&&card.checkpoints==8193&&!card.reaction_free,"bounded P2 card changed");
    auto fixture=Fixture(inputs.profile,inputs.certificate.string(),inputs.work/"owning-star",80000);
    auto channels=Channels(fixture);
    EOS::CompOSE_Thermo::Options options;options.Tmin_for_derivative_MeV=0;options.clamp_to_domain=false;
    auto thermal=std::make_shared<const RC::FrozenThermalSource>(inputs.thermal,options,
      "controlled mathematical fixed-background free-gas entropy; qualified radial80000");
    auto tangent=Campaign::Tangent(fixture,inputs.profile,inputs.work);
    auto bnv_token=std::make_shared<BNV::BnvDependencyToken>();
    auto monitor=Phase6A1Test::LoadFrozenMonitor(inputs.frozen,tangent,bnv_token);
    auto run_token=std::make_shared<RC::RunDependencyToken>();
    auto spin=std::make_shared<const BNV::StaticZeroSpinHistory>(run_token);
    auto ordinary=Context(fixture,channels,thermal,spin,Campaign::Qualification(inputs.profile,inputs.certificate,inputs.entry),run_token);
    const double mu_B=Campaign::Column(inputs.coefficients,"mu_B_inf");
    const double Bdot=card.fractional_drive_per_year*tangent->B0Count()/Year;
    require(Bdot==-2.4136520263641375e37,"bounded P2 Bdot changed");
    const std::string fate_id="phase6a1-P2-terminal-fate-v1";
    BNV::ProductFateLedger fate(fate_id,{{"controlled-terminal-product",BNV::TerminalProductFate::BoundInert,1,"abstract-neutron-disappearance"}});
    auto partition=Partition(card,fixture,bnv_token,fate_id);
    auto history=std::make_shared<const Phase6A1Test::UniformProperNeutronSinkHistory>(fixture.central,tangent->B0Count(),Bdot,
      tangent->DomainIdentity(),tangent->StarIdentity(),tangent->SequenceStateIdentity(),partition->Identity(),fate_id,bnv_token);
    const std::string potential="frozen Structure-1 B0 equilibrium mu_B plus governed moving-reference actual-potential correction";
    auto source=std::make_shared<const BNV::FrozenControlledBnvRunContext>(ordinary,tangent,history,partition,fate,monitor,channels,mu_B,potential,card.identity);
    auto zero_history=std::make_shared<const Campaign::ExactZeroHistory>(tangent->B0Count(),tangent->DomainIdentity(),
      tangent->StarIdentity(),tangent->SequenceStateIdentity(),bnv_token);
    auto zero_partition=std::make_shared<const Campaign::ExactZeroPartition>(bnv_token);
    BNV::ProductFateLedger zero_fate("zero-control-fate",{{"none",BNV::TerminalProductFate::BoundInert,1,"zero-control"}});
    auto control=std::make_shared<const BNV::FrozenControlledBnvRunContext>(ordinary,tangent,zero_history,zero_partition,zero_fate,
      monitor,channels,mu_B,potential,card.identity+"-MATCHED-CONTROL");
    return {source,control};
}

struct Archived{int seq;double t0,t1,hnext;State y;std::size_t rej;};
std::vector<Archived> ReadAccepted(const std::filesystem::path& p)
{
    std::ifstream f(p);std::string line;std::getline(f,line);std::vector<Archived> v;
    while(std::getline(f,line)){auto s=Split(line);v.push_back({std::stoi(s[0]),std::stod(s[1]),std::stod(s[2]),std::stod(s[3]),
      {{std::stod(s[4]),std::stod(s[5]),std::stod(s[6])}},std::stoull(s[7])});}
    return v;
}

// mini BA12R state gate over a set of observation states
struct Gate{double max_c1=0;std::size_t n_c1=0,n_c2=0,n_c3=0,n=0;double max_c2=0,max_c3=0;};
void GateEval(Gate& g,const State& B,const State& R,const State& U)
{
    for(int i=0;i<3;++i)
    {
        const double dBR=std::abs(B[i]-R[i]),dRU=std::abs(R[i]-U[i]),M=std::max({std::abs(B[i]),std::abs(R[i]),std::abs(U[i])});
        const double DR=REFI.atol[i]+REFI.rtol*M,DU=ULTR.atol[i]+ULTR.rtol*M,F=std::max(DU,64*Ulp(M));
        const double c1=dRU/DR;g.max_c1=std::max(g.max_c1,c1);if(c1>1)++g.n_c1;
        if(dBR>10*F){const double c2=dRU/dBR;g.max_c2=std::max(g.max_c2,c2);if(c2>0.10)++g.n_c2;}
        else{const double c3=dRU/(10*F);g.max_c3=std::max(g.max_c3,c3);if(c3>1)++g.n_c3;}
        ++g.n;
    }
}
} // namespace Rv

int main(int argc,char** argv)
{
    using namespace Rv;
    try
    {
        gsl_set_error_handler_off();std::cout<<std::setprecision(17)<<std::unitbuf;
        require(argc==11,"profile certificate thermal work entry frozen coefficients cases expdir output");
        Inputs in;in.profile=argv[1];in.certificate=argv[2];in.thermal=argv[3];in.work=argv[4];in.entry=argv[5];
        in.frozen=argv[6];in.coefficients=argv[7];const std::filesystem::path cases_path=argv[8],exp=argv[9];in.output=argv[10];
        require(!std::filesystem::exists(in.work)&&!std::filesystem::exists(in.output),"fresh scratch work/output required");
        std::filesystem::create_directories(in.output);const auto O=in.output;
        const auto begin=Clock::now();auto el=[&]{return std::chrono::duration<double>(Clock::now()-begin).count();};
        auto pair=BuildBoth(in);const auto& src=pair.source;const auto& ctl=pair.control;
        std::cout<<"CONTEXT_READY "<<el()<<'\n';
        src->RequireFullCurrent();ctl->RequireFullCurrent();std::cout<<"FULL_CURRENT_OK "<<el()<<'\n';
        const auto c=Probe::ReadCases(cases_path).front();require(c.index==32&&c.knots==1,"case");

        // ---------------- D0 production reconstructor reproduction (exact)
        {
            BNV::AcceptedStepRecord record;record.ordinal=1;record.t_left_s=c.left;record.t_right_s=c.right;record.y_left=c.yl;record.y_right=c.yr;record.cstar_knots_crossed=1;
            BNV::ObservationBracket bracket{32,c.obs,0,1,c.left,c.right,false};BNV::Rk8pdCheckpointReconstructor recon;std::size_t id=1000;
            auto q=recon.Reconstruct(bracket,{record},[&]{return std::make_unique<ActualCheckpointContext>(src,++id);});
            const State e1{{0.12472490938574241,-2.0287605965623057e-7,-5.0871537810150439e-7}},e2{{0.12472490938614615,-2.0287605965622805e-7,-5.0871537810149634e-7}};
            require(q.O1_state==e1&&q.O2_state==e2&&q.status==BNV::CheckpointStatus::NumericallyUnresolved,"archived failure did not reproduce");
            std::ofstream f(O/"D0-reproduction.tsv");f<<std::setprecision(17)<<"comp\tO1\tO2\td\tD_O1\tF_O\tF_i\tU\td_over_D\tU_over_02F\n";
            for(int i=0;i<3;++i)f<<i<<'\t'<<q.O1_state[i]<<'\t'<<q.O2_state[i]<<'\t'<<q.qualification.d_O[i]<<'\t'<<q.qualification.D_O1[i]<<'\t'<<q.qualification.F_O[i]<<'\t'<<q.qualification.F_i[i]<<'\t'<<q.qualification.U_O[i]<<'\t'<<q.qualification.d_O[i]/q.qualification.D_O1[i]<<'\t'<<q.qualification.U_O[i]/(.2*q.qualification.F_i[i])<<'\n';
            std::cout<<"D0 ARCHIVED_FAILURE_REPRODUCED_EXACTLY "<<el()<<'\n';
            // smooth controls through the production reconstructor
            auto cases=Probe::ReadCases(cases_path);std::ofstream sc(O/"D6-smooth-controls.tsv");sc<<std::setprecision(17)<<"obs\tstatus\tcomp\tO1\tO2\td_over_D\tU_over_02F\n";
            for(std::size_t j=1;j<cases.size();++j){auto a=cases[j];BNV::AcceptedStepRecord r;r.ordinal=1;r.t_left_s=a.left;r.t_right_s=a.right;r.y_left=a.yl;r.y_right=a.yr;
              BNV::ObservationBracket b{std::size_t(a.index),a.obs,0,1,a.left,a.right,false};auto qq=recon.Reconstruct(b,{r},[&]{return std::make_unique<ActualCheckpointContext>(src,++id);});
              for(int i=0;i<3;++i)sc<<a.index<<'\t'<<(qq.status==BNV::CheckpointStatus::Qualified?"Qualified":"Unresolved")<<'\t'<<i<<'\t'<<qq.O1_state[i]<<'\t'<<qq.O2_state[i]<<'\t'<<qq.qualification.d_O[i]/qq.qualification.D_O1[i]<<'\t'<<qq.qualification.U_O[i]/(.2*qq.qualification.F_i[i])<<'\n';}
            std::cout<<"D6 smooth controls done "<<el()<<'\n';
        }
        Rhs f(src,1);State tmp;f.Eval(c.left,c.yl,tmp);
        const auto& cache=Probe::Cache(*src->OrdinaryContext()->DriverContext().star);require(cache.loaded&&cache.Tinf_MeV.size()==160,"cache");
        Knots K{cache.Tinf_MeV,cache.C_star};
        {std::ofstream kf(O/"knots.tsv");kf<<std::setprecision(17)<<"i\tT_MeV\tC\n";for(std::size_t i=0;i<K.T.size();++i)kf<<i<<'\t'<<K.T[i]<<'\t'<<K.C[i]<<'\n';}
        require(K.T[95]==0.0097145208258697432,"knot 95 value");

        // ---------------- D1/D2/D3 obs-32 hierarchy, events, split
        std::ofstream d(O/"D-obs32.tsv");d<<std::setprecision(17)<<"label\tmethod\tlevel\tt_event\tx\teta_e\teta_mu\tacc\trej\trhs\textra\n";
        const Tol* levels[]={&L1,&L2,&L3,&L4};
        for(auto L:levels){auto s=Adaptive(f,gsl_odeiv2_step_rk8pd,*L,c.left,c.yl,c.obs,c.obs-c.left);d<<"unsplit\trk8pd\t"<<L->name<<"\t-\t"<<S(s.y)<<'\t'<<s.acc<<'\t'<<s.rej<<'\t'<<s.rhs<<"\t-\n";}
        std::map<std::string,Ev> events;
        for(auto L:levels){auto e=Locate(f,gsl_odeiv2_step_rk8pd,*L,c.left,c.yl,K,95,c.obs,+1);events[std::string("rk8pd-")+L->name]=e;
            d<<"event\trk8pd\t"<<L->name<<'\t'<<e.t<<'\t'<<S(e.y)<<'\t'<<e.iters<<"\t-\t"<<e.ivps<<"\tg_MeV="<<e.g_MeV<<";last_dt="<<e.last_dt<<'\n';}
        for(auto L:{&L3,&L4}){auto e=Locate(f,gsl_odeiv2_step_rkf45,*L,c.left,c.yl,K,95,c.obs,+1);events[std::string("rkf45-")+L->name]=e;
            d<<"event\trkf45\t"<<L->name<<'\t'<<e.t<<'\t'<<S(e.y)<<'\t'<<e.iters<<"\t-\t"<<e.ivps<<"\tg_MeV="<<e.g_MeV<<";last_dt="<<e.last_dt<<'\n';}
        const double tk=events["rk8pd-O4"].t;
        for(auto L:levels)
        {
            for(int mode=0;mode<2;++mode)
            {
                const double te=mode==0?events[std::string("rk8pd-")+L->name].t:tk;
                auto a=Adaptive(f,gsl_odeiv2_step_rk8pd,*L,c.left,c.yl,te,te-c.left);auto b=Adaptive(f,gsl_odeiv2_step_rk8pd,*L,te,a.y,c.obs,c.obs-te);
                d<<(mode==0?"split-own-event":"split-common-event")<<"\trk8pd\t"<<L->name<<'\t'<<te<<'\t'<<S(b.y)<<'\t'<<a.acc<<'+'<<b.acc<<'\t'<<a.rej<<'+'<<b.rej<<'\t'<<a.rhs+b.rhs<<"\tleft_x="<<a.y[0]<<'\n';
            }
        }
        for(auto L:{&L2,&L3,&L4})
        {
            auto a=Adaptive(f,gsl_odeiv2_step_rkf45,*L,c.left,c.yl,tk,tk-c.left);auto b=Adaptive(f,gsl_odeiv2_step_rkf45,*L,tk,a.y,c.obs,c.obs-tk);
            d<<"split-common-event\trkf45\t"<<L->name<<'\t'<<tk<<'\t'<<S(b.y)<<'\t'<<a.acc<<'+'<<b.acc<<'\t'<<a.rej<<'+'<<b.rej<<'\t'<<a.rhs+b.rhs<<"\t-\n";
            auto u=Adaptive(f,gsl_odeiv2_step_rkf45,*L,c.left,c.yl,c.obs,c.obs-c.left);
            d<<"unsplit\trkf45\t"<<L->name<<"\t-\t"<<S(u.y)<<'\t'<<u.acc<<'\t'<<u.rej<<'\t'<<u.rhs<<"\t-\n";
        }
        d.close();std::cout<<"D1-D3 done "<<el()<<'\n';

        // ---------------- D4 fixed-step convergence (split at tk vs unsplit)
        {
            std::ofstream fx(O/"D4-fixed-step.tsv");fx<<std::setprecision(17)<<"form\tmethod\tN\tx\teta_e\teta_mu\n";
            for(long N:{1L,2L,4L,8L,16L,32L,64L})
            {auto a=Fixed(f,gsl_odeiv2_step_rk8pd,c.left,c.yl,tk,N);auto b=Fixed(f,gsl_odeiv2_step_rk8pd,tk,a,c.obs,N);fx<<"split\trk8pd\t"<<N<<'\t'<<S(b)<<'\n';}
            for(long N=1;N<=1024;N*=2)
            {auto a=Fixed(f,gsl_odeiv2_step_rkf45,c.left,c.yl,tk,N);auto b=Fixed(f,gsl_odeiv2_step_rkf45,tk,a,c.obs,N);fx<<"split\trkf45\t"<<N<<'\t'<<S(b)<<'\n';}
            for(long N=1;N<=2048;N*=2){auto b=Fixed(f,gsl_odeiv2_step_rk8pd,c.left,c.yl,c.obs,N);fx<<"unsplit\trk8pd\t"<<N<<'\t'<<S(b)<<'\n';}
            for(long N=1;N<=4096;N*=2){auto b=Fixed(f,gsl_odeiv2_step_rkf45,c.left,c.yl,c.obs,N);fx<<"unsplit\trkf45\t"<<N<<'\t'<<S(b)<<'\n';}
            for(long N:{3L,5L,7L,11L,13L,17L,19L,23L,29L,31L,37L,41L,43L,47L,53L,59L,61L,67L,71L,73L,79L,83L,89L,97L})
            {auto b=Fixed(f,gsl_odeiv2_step_rkf45,c.left,c.yl,c.obs,N);fx<<"unsplit-odd\trkf45\t"<<N<<'\t'<<S(b)<<'\n';}
            std::cout<<"D4 done "<<el()<<'\n';
        }
        // ---------------- D5 event-time perturbation (rk8pd O2 legs), and O1 legs
        {
            std::ofstream pe(O/"D5-event-perturbation.tsv");pe<<std::setprecision(17)<<"level\tdelta_s\tx\teta_e\teta_mu\tleft_acc\tright_acc\n";
            for(auto L:{&L1,&L2})for(double dl:{-1e9,-1e8,-1e7,-1e6,-1e5,-1e4,-1e3,-1e2,-1e1,0.,1e1,1e2,1e3,1e4,1e5,1e6,1e7,1e8,1e9})
            {const double te=tk+dl;auto a=Adaptive(f,gsl_odeiv2_step_rk8pd,*L,c.left,c.yl,te,te-c.left);auto b=Adaptive(f,gsl_odeiv2_step_rk8pd,*L,te,a.y,c.obs,c.obs-te);
             pe<<L->name<<'\t'<<dl<<'\t'<<S(b.y)<<'\t'<<a.acc<<'\t'<<b.acc<<'\n';}
            std::cout<<"D5 done "<<el()<<'\n';
        }

        // ---------------- K: exact replays of archived main steps + tight local reference
        {
            std::ifstream sf(exp/"steps.tsv");std::string line;std::getline(sf,line);
            std::ofstream kr(O/"K-replays.tsv");kr<<std::setprecision(17)<<"run\tseq\tkind\tbitwise\tt0\tt1\th\tx_main\tx_ref\te_x\te_eta_e\te_eta_mu\tD_x\tn_events\tt_event\tknot\txdot_event\tattempts\n";
            std::ofstream ka(O/"K-attempts.tsv");ka<<std::setprecision(17)<<"run\tseq\tattempt\tt\th\tx_before\tx_after\terr_x\terr_e\terr_m\tD_x\tratio\n";
            Rhs fc(ctl,2);fc.Eval(0,{{0,0,0}},tmp);
            while(std::getline(sf,line))
            {
                auto s=Split(line);const std::string run=s[0];const int seq=std::stoi(s[1]);
                const double t0=std::stod(s[2]),h=std::stod(s[6]),t1=std::stod(s[7]);const State y0{{std::stod(s[3]),std::stod(s[4]),std::stod(s[5])}},y1{{std::stod(s[8]),std::stod(s[9]),std::stod(s[10])}};
                Rhs& r=run=="source"?f:fc;const int dir=run=="source"?+1:-1;
                auto m=RunMain(r,K,BASE,t0,y0,h,t0+1e-9*std::abs(t0)+1e-300,dir,false,true);
                require(m.steps.size()==1,"single replay step");const auto& st=m.steps[0];
                const bool bitwise=st.t1==t1&&st.y1==y1;
                double t=t0;std::vector<Ev> evs;State yref=SplitAdvance(r,K,gsl_odeiv2_step_rk8pd,L4,t,y0,st.t1,dir,&evs);
                State dyk{};double tev=NAN;int kn=-1;if(!evs.empty()){r.Eval(evs[0].t,evs[0].y,dyk);tev=evs[0].t;kn=evs[0].knot;}
                const double Dx=BASE.atol[0]+BASE.rtol*std::abs(st.y1[0]);
                kr<<run<<'\t'<<seq<<'\t'<<s[11]<<'\t'<<bitwise<<'\t'<<t0<<'\t'<<st.t1<<'\t'<<st.t1-t0<<'\t'<<st.y1[0]<<'\t'<<yref[0]<<'\t'<<st.y1[0]-yref[0]<<'\t'<<st.y1[1]-yref[1]<<'\t'<<st.y1[2]-yref[2]<<'\t'<<Dx<<'\t'<<evs.size()<<'\t'<<tev<<'\t'<<kn<<'\t'<<dyk[0]<<'\t'<<m.attempts.size()<<'\n';
                for(std::size_t i=0;i<m.attempts.size();++i){const auto& a=m.attempts[i];const double D=BASE.atol[0]+BASE.rtol*std::abs(a.after[0]);
                  ka<<run<<'\t'<<seq<<'\t'<<i<<'\t'<<a.t<<'\t'<<a.h<<'\t'<<a.before[0]<<'\t'<<a.after[0]<<'\t'<<a.err[0]<<'\t'<<a.err[1]<<'\t'<<a.err[2]<<'\t'<<D<<'\t'<<std::abs(a.err[0])/D<<'\n';}
                std::cout<<"K "<<run<<' '<<seq<<' '<<s[11]<<" bitwise "<<bitwise<<" e_x "<<st.y1[0]-yref[0]<<" e/D "<<(st.y1[0]-yref[0])/Dx<<'\n';
            }
            std::cout<<"K done "<<el()<<'\n';
        }

        // ---------------- M: bounded windows, three tiers, unsplit vs knot-boundary main, ideal passive observation
        auto Window=[&](const std::string& tag,Rhs& r,int dir,double t0,State y0,double h0,double t_stop,const std::vector<Archived>& arch,std::size_t arch_first)
        {
            std::map<std::string,Main> runs;
            for(const Tol* T:{&BASE,&REFI,&ULTR})for(bool split:{false,true})
                runs[std::string(T->name)+(split?"-split":"-unsplit")]=RunMain(r,K,*T,t0,y0,h0,t_stop,dir,split,false);
            // authenticate M1 = archived main
            const auto& m1=runs["BASELINE-unsplit"];std::size_t match=0;
            for(std::size_t i=0;i<m1.steps.size()&&arch_first+i<arch.size();++i){const auto& a=arch[arch_first+i];if(a.t1==m1.steps[i].t1&&a.y==m1.steps[i].y1)++match;else break;}
            std::cout<<"M "<<tag<<" BASELINE-unsplit steps "<<m1.steps.size()<<" bitwise_prefix_match "<<match<<'\n';
            std::ofstream rs(O/("M-"+tag+"-runs.tsv"));rs<<std::setprecision(17)<<"run\tsteps\trejected\twasted\tevents\trhs\tt_end\tx_end\n";
            for(auto& [name,m]:runs)rs<<name<<'\t'<<m.steps.size()<<'\t'<<m.rej<<'\t'<<m.wasted<<'\t'<<m.events.size()<<'\t'<<m.rhs<<'\t'<<m.steps.back().t1<<'\t'<<m.steps.back().y1[0]<<'\n';
            std::ofstream ev(O/("M-"+tag+"-events.tsv"));ev<<std::setprecision(17)<<"run\tknot\tt_event\tx\tg_MeV\titers\tivps\tlast_dt\n";
            for(auto& [name,m]:runs)for(auto& e:m.events)ev<<name<<'\t'<<e.knot<<'\t'<<e.t<<'\t'<<e.y[0]<<'\t'<<e.g_MeV<<'\t'<<e.iters<<'\t'<<e.ivps<<'\t'<<e.last_dt<<'\n';
            std::ofstream st(O/("M-"+tag+"-steps.tsv"));st<<std::setprecision(17)<<"run\ti\tt0\tt1\tx1\te1\tm1\thnext\trej_cum\tboundary_knot\n";
            for(auto& [name,m]:runs)for(std::size_t i=0;i<m.steps.size();++i){const auto& q=m.steps[i];st<<name<<'\t'<<i<<'\t'<<q.t0<<'\t'<<q.t1<<'\t'<<S(q.y1)<<'\t'<<q.hnext<<'\t'<<q.rej_cum<<'\t'<<q.boundary_knot<<'\n';}
            // reference at observation times and at M1 endpoints
            double end=t_stop;for(auto& [name,m]:runs)end=std::min(end,m.steps.back().t1);
            std::vector<double> times;for(long i=0;i<=8192;++i){const double tt=T_FINAL*double(i)/double(8192);if(tt>t0&&tt<=end)times.push_back(tt);}
            std::ofstream ob(O/("M-"+tag+"-observations.tsv"));ob<<std::setprecision(17)<<"t\tref_x\tref_e\tref_m";
            for(auto& [name,m]:runs)ob<<'\t'<<name<<"_x\t"<<name<<"_e\t"<<name<<"_m";ob<<'\n';
            double tr=t0;State yr=y0;std::map<std::string,Gate> gates;std::map<std::string,double> maxerr;
            for(double tt:times)
            {
                yr=SplitAdvance(r,K,gsl_odeiv2_step_rk8pd,L4,tr,yr,tt,dir);ob<<tt<<'\t'<<S(yr);
                std::map<std::string,State> o;for(auto& [name,m]:runs){o[name]=Observe(r,K,m,tt,dir);ob<<'\t'<<S(o[name]);}
                ob<<'\n';
                for(std::string form:{"unsplit","split"})GateEval(gates[form],o["BASELINE-"+form],o["REFINED-"+form],o["ULTRA-"+form]);
                for(auto& [name,y]:o){const Tol* T=name.rfind("BASELINE",0)==0?&BASE:name.rfind("REFINED",0)==0?&REFI:&ULTR;
                  for(int i=0;i<3;++i){const double D=T->atol[i]+T->rtol*std::abs(yr[i]);maxerr[name+"#"+std::to_string(i)]=std::max(maxerr[name+"#"+std::to_string(i)],std::abs(y[i]-yr[i])/D);}}
            }
            std::ofstream gs(O/("M-"+tag+"-gate.tsv"));gs<<std::setprecision(17)<<"form\tn_component_obs\tmax_dRU_over_DR\tn_fail_c1\tmax_contraction\tn_fail_c2\tmax_floor_ratio\tn_fail_c3\n";
            for(auto& [form,g]:gates)gs<<form<<'\t'<<g.n<<'\t'<<g.max_c1<<'\t'<<g.n_c1<<'\t'<<g.max_c2<<'\t'<<g.n_c2<<'\t'<<g.max_c3<<'\t'<<g.n_c3<<'\n';
            std::ofstream me(O/("M-"+tag+"-true-error.tsv"));me<<std::setprecision(17)<<"run_component\tmax_abs_err_over_D_tier\n";for(auto& [k,v]:maxerr)me<<k<<'\t'<<v<<'\n';
            std::cout<<"M "<<tag<<" observations "<<times.size()<<" done "<<el()<<'\n';
            return runs;
        };
        {
            auto arch=ReadAccepted(exp/"source-accepted.tsv");const auto& s20=arch.at(19);require(s20.seq==20&&s20.t1==c.left&&s20.y==c.yl,"source step 20 identity");
            auto runs=Window("source",f,+1,c.left,c.yl,s20.hnext,1.0e12,arch,20);
            // persistence of the knot-95 local error under the exact (split, tight) flow
            const auto& m1=runs["BASELINE-unsplit"];require(m1.steps[0].t1==c.right&&m1.steps[0].y1==c.yr,"M1 first step = archived step 21");
            double ta=c.left;State yref=SplitAdvance(f,K,gsl_odeiv2_step_rk8pd,L4,ta,c.yl,c.right,+1);
            std::ofstream pp(O/"P-persistence.tsv");pp<<std::setprecision(17)<<"t\tdx\tde\tdm\tx_ref\n";
            double tA=c.right,tB=c.right;State yA=c.yr,yB=yref;pp<<c.right<<'\t'<<yA[0]-yB[0]<<'\t'<<yA[1]-yB[1]<<'\t'<<yA[2]-yB[2]<<'\t'<<yB[0]<<'\n';
            for(double dt:{1e9,3e9,1e10,3e10,1e11,2e11,3e11,5e11,1e12,2e12,3e12,5e12})
            {const double tt=c.right+dt;yA=SplitAdvance(f,K,gsl_odeiv2_step_rk8pd,L4,tA,yA,tt,+1);yB=SplitAdvance(f,K,gsl_odeiv2_step_rk8pd,L4,tB,yB,tt,+1);
             pp<<tt<<'\t'<<yA[0]-yB[0]<<'\t'<<yA[1]-yB[1]<<'\t'<<yA[2]-yB[2]<<'\t'<<yB[0]<<'\n';}
            std::cout<<"P done "<<el()<<'\n';
        }
        {
            Rhs fc(ctl,3);auto arch=ReadAccepted(exp/"control-accepted.tsv");const auto& s=arch.at(48);require(s.seq==49,"control step 49 identity");
            Window("control",fc,-1,s.t1,s.y,s.hnext,9.0e12,arch,49);
        }
        src->RequireFullCurrent();ctl->RequireFullCurrent();
        std::ofstream done(O/"completion.tsv");done<<std::setprecision(17)<<"key\tvalue\nwall_s\t"<<el()<<"\ngsl\t"<<gsl_version<<"\nfull_trajectories\t0\n";
        std::cout<<"REVIEW_DIAGNOSTIC_COMPLETE "<<el()<<'\n';return 0;
    }
    catch(const std::exception& e){std::cerr<<"STOP "<<e.what()<<'\n';return 1;}
}
