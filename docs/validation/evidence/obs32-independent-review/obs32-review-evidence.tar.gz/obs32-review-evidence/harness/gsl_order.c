#include <stdio.h>
#include <math.h>
#include <gsl/gsl_odeiv2.h>
#include <gsl/gsl_errno.h>
static int f(double t,const double y[],double d[],void*p){(void)t;(void)p;d[0]=y[0];return GSL_SUCCESS;}
/* ramp test: y' = g(t), g = max(t-tk,0) -> exact y = (t-tk)_+^2/2 */
static double tk; static int fr(double t,const double y[],double d[],void*p){(void)y;(void)p;d[0]=t>tk?t-tk:0;return GSL_SUCCESS;}
int main(void){
  gsl_odeiv2_system s={f,0,1,0}; const gsl_odeiv2_step_type* T[2]={gsl_odeiv2_step_rkf45,gsl_odeiv2_step_rk8pd};
  for(int m=0;m<2;++m){ double prev=0; printf("%s\n",T[m]->name);
    for(int N=1;N<=64;N*=2){ gsl_odeiv2_step* st=gsl_odeiv2_step_alloc(T[m],1); double y=1,e,h=1.0/N; for(int i=0;i<N;i++){gsl_odeiv2_step_apply(st,i*h,h,&y,&e,0,0,&s);} double err=y-exp(1.0);
      printf("  N=%3d err=%+.4e%s\n",N,err,prev!=0?"":""); if(prev!=0) printf("     order=%.3f\n",log2(fabs(prev/err))); prev=err; gsl_odeiv2_step_free(st);} }
  /* single-step ramp kernel: rkf45, h=1 */
  gsl_odeiv2_system sr={fr,0,1,0}; gsl_odeiv2_step* st=gsl_odeiv2_step_alloc(gsl_odeiv2_step_rkf45,1);
  for(int i=1;i<10;++i){ tk=i/10.0; double y=0,e; gsl_odeiv2_step_apply(st,0,1,&y,&e,0,0,&sr); double ex=(1-tk)*(1-tk)/2; printf("ramp theta=%.1f  K_prop=%+.6f  K_errest=%+.6f\n",tk,y-ex,e);} 
  return 0;}
