#!/usr/bin/env python3
"""Reproduce the follow-up numbers quoted in the obs-32 review (no ODE integration).

Usage:
  python3 review_followups.py <worktree> <bundle_root>
    <worktree>    CompactStar-phase6a1-obs32-reconstruction-forensics checkout (read-only)
    <bundle_root> root of this evidence bundle (contains runs/, inputs/)
"""
import csv, glob, gzip, json, math, sys

WT, ROOT = sys.argv[1], sys.argv[2]
FOR = WT + "/docs/validation/evidence/obs32-forensics/runs/"


def gz_rows(p):
    with gzip.open(p, "rt") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def rows(p):
    with open(p) as f:
        return list(csv.DictReader(f, delimiter="\t"))


def ulp(m):
    return math.nextafter(m, math.inf) - m


print("== 1. Archived forensics solutions (independent reduction)")
s = {r["name"]: r for r in gz_rows(FOR + "primary/output/solutions.tsv.gz")}
s.update({r["name"]: r for r in gz_rows(FOR + "supplement/output/solutions.tsv.gz")})
ref = float(s["split-right-O3"]["x"])
for n in ["unsplit-O1", "unsplit-O2", "unsplit-O3", "unsplit-O4", "split-right-O1", "split-right-O2",
          "split-right-O3", "independent-unsplit-O2", "independent-unsplit-O3", "independent-right-O2",
          "independent-right-O3"]:
    r = s[n]
    print(f"  {n:24s} x={float(r['x'])!r:22s} x-ref={float(r['x'])-ref:+.3e} acc={r['accepted']} rej={r['rejected']} rhs={r['rhs']}")

print("== 2. Monotonicity in the obs-32 bracket (all logged RHS stages, non-control traces)")
fs = []
for fn in glob.glob(FOR + "primary/output/*.rhs.tsv.gz"):
    if "smooth" in fn:
        continue
    fs += [float(r["xdot"]) for r in gz_rows(fn)]
print(f"  samples={len(fs)} xdot min={min(fs)!r} max={max(fs)!r}")

print("== 3. Main step-21 discrepancy in physical units")
xm, xr = 0.12930946174191599, float(s["right-endpoint-rk8pd-O3"]["x"])
dx = xm - xr
T_main, T_ref = 1e8 * math.exp(xm), 1e8 * math.exp(xr)
D = 1e-12 + 1e-7 * abs(xm)
print(f"  dx={dx!r} dT/T={math.expm1(dx)!r} dT[K]={T_main-T_ref!r} T_R[K]={T_main!r}")
print(f"  dx/D_BASELINE={dx/D:.4f}  dx/GSL_estimate(1.4001e-8)={dx/1.4001e-8:.3f}  dx/F_x={dx/1.2931946174191598e-12:.4e}")
Lnu_eq, Lg, Pdir = 4.9858923559729246e32, 3.7086243911599089e33, 3.3583239602677939e34
GP = Pdir + 3.2824551920485397e22 + 4.9236827879519468e22 + Lnu_eq + Lg
print(f"  G_P~{GP:.4e}  |dPnet/dx|dx/G_P~{(8*Lnu_eq+2.42*Lg)*dx/GP:.3e}  dLnu/L~{8*dx:.3e}  dLgamma/L~{2.42*dx:.3e}")
C = 1.4700798497005163e38
print(f"  spurious DeltaU_th per jump ~{C*T_main*dx:.4e} erg = {C*T_main*dx/(Pdir*1.57788e13):.3e} of Pdir*t_final")

print("== 4. Linearized propagation of measured knot errors to t_final (archived metadata only)")
an = json.load(open(ROOT + "/runs/run2-primary/analysis.json"))
for run in ("source", "control"):
    A = rows(f"{ROOT}/inputs/{run}-accepted.tsv")
    t = [0.0] + [float(a["t1"]) for a in A]
    x = [0.0] + [float(a["x"]) for a in A]
    f = [(x[i+1]-x[i])/(t[i+1]-t[i]) for i in range(len(A))]
    xm_ = [(x[i+1]+x[i])/2 for i in range(len(A))]
    fx = []
    for i in range(len(A)):
        j = i+1 if i+1 < len(A) else i-1
        d = xm_[j]-xm_[i]
        fx.append((f[j]-f[i])/d if abs(d) > 1e-9 else (fx[-1] if fx else 0.0))
    I = [0.0]*(len(A)+1)
    for i in range(len(A)-1, -1, -1):
        I[i] = I[i+1] + fx[i]*(t[i+1]-t[i])
    tot = 0.0
    kr = [d for d in an["K"] if d["run"] == run and d["kind"] == "crossing"]
    for d in kr:
        phi = math.exp(I[d["seq"]])
        tot += d["e_x"]*phi
    Dend = 1e-12 + 1e-7*abs(x[-1])
    pos = sum(d["e_x"] > 0 for d in kr)
    print(f"  {run}: crossings={len(kr)} positive={pos} linearized final x error={tot:+.3e} ({tot/Dend:+.1f} D_BASELINE)")

print("== 5. Residual mini-BA12R failures in the corrected windows (run4: split / frozen)")
at = {"x": (1e-16, 1e-14), "e": (1e-22, 1e-20), "m": (1e-22, 1e-20)}
for tag in ("source", "control"):
    R = rows(f"{ROOT}/runs/run4-frozen-cell/M-{tag}-observations.tsv")
    for form in ("split", "frozen"):
        fails = {}
        for r in R:
            for comp in "xem":
                B, Rr, U = (float(r[f"{tier}-{form}_{comp}"]) for tier in ("BASELINE", "REFINED", "ULTRA"))
                M = max(abs(B), abs(Rr), abs(U))
                DU = at[comp][0] + 1e-11*M
                DR = at[comp][1] + 1e-9*M
                F = max(DU, 64*ulp(M))
                dBR, dRU = abs(B-Rr), abs(Rr-U)
                if dBR > 10*F and dRU/dBR > 0.1:
                    fails.setdefault(("contraction", comp), []).append((float(r["t"]), dRU/dBR, dBR/DR, dRU/DR))
                if dBR <= 10*F and dRU > 10*F:
                    fails.setdefault(("floor", comp), []).append((float(r["t"]), dRU/(10*F), dBR/DR, dRU/DR))
        if not fails:
            print(f"  {tag} {form}: none")
        for k, v in fails.items():
            w = max(v, key=lambda z: z[1])
            print(f"  {tag} {form} {k}: n={len(v)} worst={w[1]:.3f} at t={w[0]:.4e} dBR/D_R={w[2]:.3f} dRU/D_R={w[3]:.3f}")
