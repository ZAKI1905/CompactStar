#!/usr/bin/env python3
"""Independent read-only reduction for the Phase-6A-1 obs-32 review.
No ODE is integrated. Reads committed evidence only."""
import gzip, csv, math, json, sys, ctypes, ctypes.util
from fractions import Fraction as Fr

WT = "/Users/keeper/Documents/CompactStar/worktrees/CompactStar-phase6a1-obs32-reconstruction-forensics"
EV = WT + "/docs/validation/evidence"
libm = ctypes.CDLL(ctypes.util.find_library("m"))
libm.fma.restype = ctypes.c_double
libm.fma.argtypes = [ctypes.c_double] * 3
fma = libm.fma

def rows(path):
    op = gzip.open if path.endswith(".gz") else open
    with op(path, "rt") as f:
        return list(csv.DictReader(f, delimiter="\t"))

def ulp(m):
    return math.nextafter(m, math.inf) - m

out = {}
# ---------------------------------------------------------------- 1. budgets
w = json.load(open(EV + "/obs32-forensics/saved-witness.json"))
case = rows(EV + "/obs32-forensics/cases.tsv")[0]
yl = [float(case["x_L"]), float(case["eta_e_L"]), float(case["eta_mu_L"])]
yr = [float(case["x_R"]), float(case["eta_e_R"]), float(case["eta_mu_R"])]
O1 = [float(w["x_O1"]), float(w["eta_e_O1"]), float(w["eta_mu_O1"])]
O2 = [float(w["x_O2"]), float(w["eta_e_O2"]), float(w["eta_mu_O2"])]
a1 = [1e-17, 1e-23, 1e-23]; a2 = [1e-18, 1e-24, 1e-24]; au = [1e-16, 1e-22, 1e-22]
bud = []
for i in range(3):
    MO = max(abs(O1[i]), abs(O2[i]))
    d = abs(O2[i] - O1[i])
    D1 = fma(1e-12, MO, a1[i])
    FO = max(fma(1e-13, MO, a2[i]), 64 * ulp(MO))
    Mi = max(abs(yl[i]), abs(yr[i]), abs(O1[i]), abs(O2[i]))
    Fi = max(fma(1e-11, Mi, au[i]), 64 * ulp(Mi))
    U = 2 * max(d, FO)
    bud.append(dict(d=d, D_O1=D1, F_O=FO, F_i=Fi, U=U, d_over_D=d / D1, U_over_02F=U / (0.20 * Fi)))
out["budgets"] = bud
names = {"d": "d_x", "D_O1": "D_O1_x", "F_i": "F_x", "U": "U_x"}
out["budget_exact_match_x"] = {k: (bud[0][k] == float(w[v])) for k, v in names.items()}

# ---------------------------------------------------------------- 2. Cstar structure
cache = rows(EV + "/obs32-forensics/runs/primary/output/cstar-cache.tsv.gz")
Tg = [float.fromhex(r["T_hex"]) for r in cache]
Cg = [float.fromhex(r["C_hex"]) for r in cache]
kB = 8.61733326214518e-5 * 1e-6
def TM(x):
    return 1e8 * math.exp(x) * kB
def interp(T, i):
    w_ = (math.log(T) - math.log(Tg[i])) / (math.log(Tg[i + 1]) - math.log(Tg[i]))
    return (1 - w_) * Cg[i] + w_ * Cg[i + 1]
def slope(i):  # dC/dT on cell i evaluated at T (times T): T dC/dT = (C1-C0)/ln(T1/T0)
    return (Cg[i + 1] - Cg[i]) / (math.log(Tg[i + 1]) - math.log(Tg[i]))
k = 95
Tk = Tg[k]
below = slope(k - 1) / Tk; above = slope(k) / Tk
out["knot95"] = dict(T_MeV=Tk, T_K=Tk / kB, C=Cg[k], C_from_below=interp(Tk, k - 1), C_from_above=interp(Tk, k),
                     dCdT_below_erg_K2=below * kB, dCdT_above_erg_K2=above * kB,
                     rel_jump=above / below - 1, cell_ratio=Tg[k + 1] / Tg[k],
                     T_dC_over_C_jump=(slope(k) - slope(k - 1)) / Cg[k])
# all knots in the trajectory ranges: local power p = dlnC/dlnT, slope ratio, kink strength
kn = []
for i in range(60, 104):
    p_b = math.log(Cg[i] / Cg[i - 1]) / math.log(Tg[i] / Tg[i - 1])
    kn.append(dict(i=i, T_K=Tg[i] / kB, x_knot=math.log(Tg[i] / kB / 1e8), p_below=p_b,
                   slope_ratio=slope(i) / slope(i - 1), kink=(slope(i) - slope(i - 1)) / Cg[i]))
out["knots"] = kn

# ---------------------------------------------------------------- 3. Peano kernels
# GSL rkf45 (advances 5th order solution), ec = b5 - b4 as in gsl/ode-initval2/rkf45.c
c = [Fr(0), Fr(1, 4), Fr(3, 8), Fr(12, 13), Fr(1), Fr(1, 2)]
b5 = [Fr(16, 135), Fr(0), Fr(6656, 12825), Fr(28561, 56430), Fr(-9, 50), Fr(2, 55)]
ec = [Fr(1, 360), Fr(0), Fr(-128, 4275), Fr(-2197, 75240), Fr(1, 50), Fr(2, 55)]
assert sum(b5) == 1 and sum(bi * ci for bi, ci in zip(b5, c)) == Fr(1, 2)
assert sum(ec) == 0 and sum(e * ci for e, ci in zip(ec, c)) == 0
def K(b, th):  # quadrature Peano kernel for ramp (t-θh)_+ : RK - exact, per unit Δ h^2
    return sum(float(bi) * max(float(ci) - th, 0.0) for bi, ci in zip(b, c)) - (1 - th) ** 2 / 2
def Kerr(th):
    return sum(float(e) * max(float(ci) - th, 0.0) for e, ci in zip(ec, c))
grid = [i / 20000 for i in range(1, 20000)]
A = [abs(K(b5, t)) / abs(Kerr(t)) if Kerr(t) != 0 else math.inf for t in grid]
As = sorted(A)
zeros = [grid[i] for i in range(1, len(grid)) if Kerr(grid[i - 1]) * Kerr(grid[i]) < 0]
z5 = [grid[i] for i in range(1, len(grid)) if K(b5, grid[i - 1]) * K(b5, grid[i]) < 0]
out["rkf45_kernel"] = dict(K5_max=max(abs(K(b5, t)) for t in grid), Kerr_max=max(abs(Kerr(t)) for t in grid),
                           A_theta_to_0=float(b5[0] / ec[0]), A_theta_to_1=float(b5[4] / ec[4]),
                           A_median=As[len(As) // 2], A_p10=As[len(As) // 10], A_p90=As[9 * len(As) // 10],
                           frac_A_gt_1=sum(a > 1 for a in A) / len(A), frac_A_gt_10=sum(a > 10 for a in A) / len(A),
                           Kerr_zero_thetas=zeros, K5_zero_thetas=z5,
                           K5_mean=sum(K(b5, t) for t in grid) / len(grid))
# rk8pd (Prince-Dormand 8(7)) propagated weights and nodes, for event-location sensitivity
c8 = [0, 1/18, 1/12, 1/8, 5/16, 3/8, 59/400, 93/200, 5490023248/9719169821, 13/20, 1201146811/1299019798, 1, 1]
b8 = [14005451/335480064, 0, 0, 0, 0, -59238493/1068277825, 181606767/758867731, 561292985/797845732,
      -1041891430/1371343529, 760417239/1151165299, 118820643/751138087, -528747749/2220607170, 1/4]
out["rk8pd_end_weights"] = dict(sum_b=sum(b8), b_at_c0=b8[0], b_at_c1=b8[11] + b8[12],
                               K8_max=max(abs(sum(bi * max(ci - t, 0) for bi, ci in zip(b8, c8)) - (1 - t) ** 2 / 2) for t in grid))

# ---------------------------------------------------------------- 4. main trajectories
def bracket(T):
    import bisect
    j = bisect.bisect_right(Tg, T)
    return max(0, min(158, j - 1))
def crossings(path, label):
    st = rows(path)
    res = []; prev_rej = 0; mono = True; dirn = 0
    for r in st:
        x0, x1 = float(r["x_before"]), float(r["x_after"])
        rej = int(r["cumulative_rejected"]) - prev_rej; prev_rej = int(r["cumulative_rejected"])
        s = (x1 > x0) - (x1 < x0)
        if s:
            if dirn and s != dirn: mono = False
            dirn = dirn or s
        cb, ca = bracket(TM(x0)), bracket(TM(x1))
        if cb != int(r["cstar_cell_before"]) or ca != int(r["cstar_cell_after"]):
            res.append(dict(seq=int(r["sequence"]), mismatch=True))
        if cb != ca:
            lo, hi = min(cb, ca), max(cb, ca)
            for kk in range(lo + 1, hi + 1):
                xk = math.log(Tg[kk] / kB / 1e8)
                th = (xk - x0) / (x1 - x0)  # linear-in-time estimate of knot position
                dx = x1 - x0
                kink = (slope(kk) - slope(kk - 1)) / Cg[kk]  # = T*dC'/C at knot
                # local error model: e = h^2 * [y''] * K5(theta), [y''] = -f^2*kink, f ~ dx/h
                pred = -kink * dx * dx * K(b5, th)
                est = -kink * dx * dx * Kerr(th)
                D = 1e-12 + 1e-7 * abs(x1)
                res.append(dict(seq=int(r["sequence"]), knot=kk, t0=float(r["t_before_s"]), h=float(r["step_s"]),
                                x0=x0, x1=x1, dx=dx, theta_lin=th, rejections_in_call=rej,
                                predicted_local_error_x=pred, predicted_estimate_x=est, D_x=D,
                                pred_over_D=abs(pred) / D, est_over_D=abs(est) / D))
    return dict(label=label, steps=len(st), monotonic=mono, direction=dirn, crossings=res)
C = EV + "/bnv-resume/clean-campaign"
out["source"] = crossings(C + "/source-baseline/main.internal_steps.tsv.gz", "source")
out["control"] = crossings(C + "/control-baseline/main.internal_steps.tsv.gz", "control")

# final temporal decade rejection fraction (BA12R 6.2 heuristic, BASELINE only, informational)
for lab in ("source", "control"):
    st = rows(C + f"/{lab}-baseline/main.internal_steps.tsv.gz")
    tf = float(st[-1]["t_after_s"])
    acc = [r for r in st if float(r["t_before_s"]) >= tf / 10]
    rej = int(st[-1]["cumulative_rejected"]) - int([r for r in st if float(r["t_before_s"]) < tf / 10][-1]["cumulative_rejected"])
    out[lab + "_final_decade"] = dict(accepted=len(acc), rejected=rej, frac_rej_over_attempts=rej / (rej + len(acc)))

# ---------------------------------------------------------------- 5. GSL controller replay of step 21 (model)
# standard GSL hadjust: rmax = max |E|/D ; if rmax>1.1: r = 0.9*rmax^(-1/q) clamp >=0.2 ; q = order (rkf45: 5)
# For the kink-dominated estimate the model error is |kink*f^2*h^2*Kerr(theta)|.
s21 = [r for r in rows(C + "/source-baseline/main.internal_steps.tsv.gz") if r["sequence"] in ("20", "21")]
h = float(s21[0]["suggested_next_h_s"]); t0 = float(s21[1]["t_before_s"]); x0 = float(s21[1]["x_before"])
xk = math.log(Tg[95] / kB / 1e8)
f0 = (float(s21[1]["x_after"]) - x0) / float(s21[1]["step_s"])  # mean slope proxy
kink = (slope(95) - slope(94)) / Cg[95]
seq = []
for it in range(8):
    th = (xk - x0) / (f0 * h) if f0 * h > 0 else 2
    dx = f0 * h
    if th >= 1:
        est = 0.0
    else:
        est = abs(kink * dx * dx * Kerr(th))
    D = 1e-12 + 1e-7 * abs(x0 + dx)
    r = est / D
    seq.append(dict(h=h, theta=th, est_over_D=r))
    if r > 1.1:
        h = h * max(0.2, 0.9 * r ** (-1 / 5))
    else:
        break
out["step21_controller_model"] = dict(sequence=seq, archived_accepted_h=float(s21[1]["step_s"]),
                                      archived_rejections=int(s21[1]["cumulative_rejected"]) - int(s21[0]["cumulative_rejected"]))
json.dump(out, open(sys.argv[1], "w"), indent=1)
print(json.dumps({k: out[k] for k in ("budgets", "budget_exact_match_x", "knot95", "rkf45_kernel", "rk8pd_end_weights",
                                      "source_final_decade", "control_final_decade", "step21_controller_model")}, indent=1))
for lab in ("source", "control"):
    s = out[lab]
    print(lab, "steps", s["steps"], "monotonic", s["monotonic"], "dir", s["direction"], "crossings", len([c for c in s["crossings"] if "knot" in c]),
          "mismatch", [c for c in s["crossings"] if c.get("mismatch")])
    for cr in s["crossings"]:
        if "knot" in cr:
            print(f"  seq {cr['seq']:3d} knot {cr['knot']:3d} h {cr['h']:.4e} dx {cr['dx']:+.5f} th {cr['theta_lin']:.4f} rej {cr['rejections_in_call']} "
                  f"pred_e {cr['predicted_local_error_x']:+.3e} pred/D {cr['pred_over_D']:.2f} est/D {cr['est_over_D']:.3f}")
