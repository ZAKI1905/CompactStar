import hashlib,json,pathlib,subprocess
p=pathlib.Path('/mnt/sdd/zaki/CompactStar/linux-transition-20261010/toolchain')
s=p.parent/'sources/CompactStar'
paths=[s/'tests/baselines/phase5c_chemical_coefficients.json',p/'build/CompactStar-Debug/tests/phase5c-production/run-ou64qvue/t8192-r80000/candidate.json']
mac,linux=[json.loads(x.read_text()) for x in paths]
assert mac['units']==linux['units'] and mac['fixture']==linux['fixture']
assert mac['numerical_error']['classification']==linux['numerical_error']['classification']
def flatten(v):
 if isinstance(v,list):return [x for item in v for x in flatten(item)]
 return [float(v)]
result={'status':'DIAGNOSTIC_CONSISTENCY_ONLY_NOT_GOVERNED_ACCEPTANCE','predeclaration_commit':subprocess.check_output(['git','-C',str(s),'rev-parse','HEAD'],text=True).strip(),'inputs':[{'path':str(x),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in paths],'fixture':mac['fixture'],'units':mac['units'],'components':{}}
for key in ('G','Q','Z','I','W'):
 a,b=[flatten(d['values'][key]) for d in (mac,linux)]
 ea,eb=[flatten(d['numerical_error'][key]) for d in (mac,linux)]
 assert len(a)==len(b)==len(ea)==len(eb)
 rows=[]
 for i,(x,y,ex,ey) in enumerate(zip(a,b,ea,eb)):
  assert ex>=0 and ey>=0
  error=abs(x-y);budget=ex+ey
  rows.append(dict(flat_index=i,mac=x,linux=y,absolute=error,relative=error/max(abs(x),abs(y)) if x or y else 0,combined_uncertainty=budget,ratio=error/budget if budget else None,within_supplied_uncertainty=error<=budget))
 result['components'][key]={'rows':rows,'max_relative':max(x['relative'] for x in rows),'max_uncertainty_ratio':max(x['ratio'] or 0 for x in rows),'all_within_supplied_uncertainty':all(x['within_supplied_uncertainty'] for x in rows)}
(p/'logs/phase5c-coefficient-differences.json').write_text(json.dumps(result,indent=2)+'\n')
for key,value in result['components'].items():print(key,value['max_relative'],value['max_uncertainty_ratio'],value['all_within_supplied_uncertainty'])
