#!/bin/bash
set -euo pipefail
SRC=/mnt/sdd/zaki/CompactStar/linux-transition-20261010/sources/CompactStar
GSL="$TC/install/gsl-2.7.1"
for mode in Debug Release; do
 opt=-O0
 if [ "$mode" = Release ]; then opt=-O3; fi
 "$CXX" -std=c++17 "$opt" -g -ffp-contract=off -I"$SRC" -I"$TC/build/CompactStar-$mode/generated/include" -I"$TC/install/$mode/Zaki/include" -I"$TC/install/$mode/CONFIND/include" -I"$GSL/include" "$TC/pe-onset-diagnostic.cpp" "$TC/build/CompactStar-$mode/libCompactStar.a" "$TC/install/$mode/CONFIND/lib/libCONFIND.a" "$TC/install/$mode/Zaki/lib/libZaki.a" "$GSL/lib/libgsl.a" "$GSL/lib/libgslcblas.a" "$TC/sysroot/usr/lib64/libz.so" -pthread -lm -o "$TC/pe-onset-$mode"
 set +e
 "$TC/pe-onset-$mode" > "$TC/logs/pe-onset-$mode.log" 2>&1
 rc=$?
 set -e
 echo "$rc" > "$TC/logs/pe-onset-$mode.exit"
done
