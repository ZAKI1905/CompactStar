#!/bin/bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
"$TC/python/bin/python" "$TC/auth-real.py"
