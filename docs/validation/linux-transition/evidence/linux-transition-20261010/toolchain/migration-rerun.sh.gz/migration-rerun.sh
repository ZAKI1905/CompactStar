#!/bin/bash
set -u
export PYTHONDONTWRITEBYTECODE=1
ctest --test-dir "$TC/build/CompactStar-Debug" -R '^(taskmanager_T1|taskmanager_T2|taskmanager_replay|taskmanager_observations)$' --output-on-failure --output-junit "$TC/logs/CompactStar-Debug-migration-rerun.xml" --timeout 900 -j1 > "$TC/logs/CompactStar-Debug-migration-rerun.log" 2>&1
rc=$?
echo "$rc" > "$TC/logs/CompactStar-Debug-migration-rerun.exit"
exit "$rc"
