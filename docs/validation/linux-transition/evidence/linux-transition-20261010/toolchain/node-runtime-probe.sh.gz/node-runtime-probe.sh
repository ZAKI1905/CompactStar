#!/bin/bash
set -euo pipefail
host=$(hostname)
exec > "$TC/logs/node-runtime-$host.log" 2>&1
hostname
date -u +%FT%TZ
cat /etc/os-release
getconf GNU_LIBC_VERSION
"$CXX" --version
"$TC/sysroot/usr/lib64/ld-linux-x86-64.so.2" --list "$TC/build/CompactStar-Debug/tests/compactstar_library_smoke"
"$TC/python/bin/python" - <<'PY'
import platform,numpy,scipy,mpmath,os
print(platform.python_version(),numpy.__version__,scipy.__version__,mpmath.__version__)
for key in ('LD_LIBRARY_PATH','LIBRARY_PATH','CPATH','CPLUS_INCLUDE_PATH'):print(key,repr(os.environ.get(key,'')))
PY
"$TC/build/CompactStar-Debug/tests/compactstar_library_smoke"
"$TC/build/CompactStar-Debug/tests/phase6_breakpoint_contract"
echo NODE_RUNTIME_SMOKE_PASS
