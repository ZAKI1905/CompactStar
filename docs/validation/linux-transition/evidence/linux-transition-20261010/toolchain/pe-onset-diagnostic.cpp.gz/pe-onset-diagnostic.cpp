// Diagnostic only: call unchanged individual PE tests after the first refusal.
#define main original_pe_test_main
#include "/mnt/sdd/zaki/CompactStar/linux-transition-20261010/sources/CompactStar/tests/eos/rotochemical_trackr_pe.cpp"
#undef main
int main() {
 const TrackRFreeGasThermodynamicProvider provider;
 const auto independent=IndependentOnsetExpression();
 const double production=provider.NeutronOnsetBaryonDensityFm3();
 std::cout << std::setprecision(25) << "DIAGNOSTIC long_double_digits=" << std::numeric_limits<long double>::digits
   << " production=" << production << " independent=" << independent
   << " absolute=" << std::abs(static_cast<long double>(production)-independent)
   << " relative=" << std::abs(static_cast<long double>(production)/independent-1.0L)
   << " threshold=" << 3e-16L << '\n';
 int failures=0,index=0;
 for(auto fn:{V1,V2,V3,V4,V5,V6,V7,V8,V9,V10,V11,V12,V13}) {
  ++index;
  try { fn(provider); }
  catch(const std::exception& e) { ++failures;std::cout << "DIAGNOSTIC PE-V" << index << " FAIL: " << e.what() << '\n'; }
 }
 std::cout << "DIAGNOSTIC failures=" << failures << "; original CTest remains unchanged\n";
 return failures ? 1 : 0;
}
