import json,os,pathlib,subprocess
p=pathlib.Path(os.environ['TC']);src=p.parent/'sources/CompactStar'
gsl=p/'install/gsl-2.7.1'
base={'CMAKE_BUILD_TYPE':'Debug','CMAKE_C_COMPILER':os.environ['CC'],'CMAKE_CXX_COMPILER':os.environ['CXX'],'CMAKE_CXX_FLAGS':'-ffp-contract=off','Python3_EXECUTABLE':str(p/'python/bin/python'),'GSL_INCLUDE_DIR':str(gsl/'include'),'GSL_LIBRARY':str(gsl/'lib/libgsl.a'),'GSL_CBLAS_LIBRARY':str(gsl/'lib/libgslcblas.a'),'ZLIB_INCLUDE_DIR':str(p/'sysroot/usr/include'),'ZLIB_LIBRARY':str(p/'sysroot/usr/lib64/libz.so'),'COMPACTSTAR_ZAKI_PREFIX':str(p/'install/Debug/Zaki'),'COMPACTSTAR_CONFIND_PREFIX':str(p/'install/Debug/CONFIND'),'COMPACTSTAR_LINUX_DEPENDENCY_LOCK':str(p/'dependency-lock-linux.json'),'BUILD_TESTING':'OFF'}
cases=[('missing-lock',{'COMPACTSTAR_LINUX_DEPENDENCY_LOCK':''},'Linux requires an explicit absolute'),('wrong-mode-prefix',{'COMPACTSTAR_ZAKI_PREFIX':str(p/'install/Release/Zaki')},'Zaki prefix mismatch'),('changed-flags',{'CMAKE_CXX_FLAGS':'-ffast-math'},'compiler flags mismatch'),('mac-lock',{'COMPACTSTAR_LINUX_DEPENDENCY_LOCK':str(src/'cmake/dependency-lock.json')},'Dependency authentication failed')]
records=[]
for name,changes,reason in cases:
 b=p/'build'/('authentication-negative-'+name);assert not b.exists()
 args=base|changes
 result=subprocess.run(['cmake','-S',str(src),'-B',str(b)]+[f'-D{k}={v}' for k,v in args.items()],capture_output=True,text=True)
 output=result.stdout+result.stderr;(p/'logs'/('authentication-'+name+'.log')).write_text(output)
 passed=result.returncode!=0 and reason in ' '.join(output.split())
 records.append(dict(name=name,returncode=result.returncode,expected_reason=reason,refused_as_expected=passed))
(p/'logs/authentication-negative-configures.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2));assert all(x['refused_as_expected'] for x in records)
