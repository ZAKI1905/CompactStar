#!/bin/bash
set -u
export PYTHONDONTWRITEBYTECODE=1
ctest --test-dir "$TC/build/CompactStar-Debug" -R '^(hartle_monopole_physics_cmf|hartle_monopole_regression)$' --output-on-failure --output-junit "$TC/logs/CompactStar-Debug-static-supplement.xml" --timeout 900 -j1 > "$TC/logs/CompactStar-Debug-static-supplement.log" 2>&1
rc=$?
echo "$rc" > "$TC/logs/CompactStar-Debug-static-supplement.exit"
exit "$rc"
